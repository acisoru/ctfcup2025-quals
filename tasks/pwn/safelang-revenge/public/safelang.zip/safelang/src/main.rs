use validation_macro::include_validated;

include_validated!("kek.rs");
